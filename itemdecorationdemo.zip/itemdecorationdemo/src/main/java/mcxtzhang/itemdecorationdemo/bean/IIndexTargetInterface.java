package mcxtzhang.itemdecorationdemo.bean;

/**
 * 介绍：某个需要被处理的字段的接口
 * 作者：zhangxutong
 * 邮箱：mcxtzhang@163.com
 * CSDN：http://blog.csdn.net/zxt0601
 * 时间： 16/09/04.
 */

public interface IIndexTargetInterface {
    String getTarget();//需要被转化成拼音，并取出首字母 索引排序的 字段
}
